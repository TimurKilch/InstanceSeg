.. _raster.fujibas:

================================================================================
FujiBAS -- Fuji BAS Scanner Image
================================================================================

.. shortname:: FujiBAS

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/raw/fujibasdataset.cpp``.

Driver capabilities
-------------------

.. supports_virtualio::

