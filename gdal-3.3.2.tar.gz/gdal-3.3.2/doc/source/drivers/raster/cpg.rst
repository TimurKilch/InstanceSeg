.. _raster.cpg:

================================================================================
CPG -- Convair PolGASP data
================================================================================

.. shortname:: CPG

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/raw/cpgdataset.cpp``.

Driver capabilities
-------------------

.. supports_georeferencing::

.. supports_virtualio::
